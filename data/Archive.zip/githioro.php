
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Nakuplan LIS</title>
        <link rel="stylesheet" href="src/leaflet.css">
        <link rel="stylesheet" href="src/css/bootstrap.css">
        <link rel="stylesheet" href="src/plugins/L.Control.MousePosition.css">
        <link rel="stylesheet" href="src/plugins/L.Control.Sidebar.css">
        <link rel="stylesheet" href="src/plugins/Leaflet.PolylineMeasure.css">
        <link rel="stylesheet" href="src/plugins/easy-button.css">
        <link rel="stylesheet" href="src/plugins/leaflet-styleeditor/css/Leaflet.StyleEditor.css">
        <link rel="stylesheet" href="src/css/font-awesome.min.css">
        <link rel="stylesheet" href="src/plugins/leaflet.awesome-markers.css">
        <link rel="stylesheet" href="src/plugins/leaflet-mapkey/MapkeyIcons.css">
        <link rel="stylesheet" href="src/plugins/leaflet-mapkey/L.Icon.Mapkey.css">
        <link rel="stylesheet" href="src/plugins/MarkerCluster.css">
        <link rel="stylesheet" href="src/plugins/MarkerCluster.Default.css">
        <link rel="stylesheet" href="src/jquery-ui.min.css">

        <script src="src/leaflet-src.js"></script>
        <script src="src/jquery-3.2.0.min.js"></script>
        <script src="src/plugins/L.Control.MousePosition.js"></script>
        <script src="src/plugins/L.Control.Sidebar.js"></script>
        <script src="src/plugins/Leaflet.PolylineMeasure.js"></script>
        <script src="src/plugins/easy-button.js"></script>
        <script src="src/plugins/leaflet-providers.js"></script>
        <script src="src/plugins/leaflet-styleeditor/javascript/Leaflet.StyleEditor.js"></script>
        <script src="src/plugins/leaflet-styleeditor/javascript/Leaflet.StyleForms.js"></script>
        <script src="src/plugins/leaflet.ajax.min.js"></script>
        <script src="src/plugins/leaflet.sprite.js"></script>
        <script src="src/plugins/leaflet.awesome-markers.min.js"></script>
        <script src="src/plugins/leaflet-mapkey/L.Icon.Mapkey.js"></script>
        <script src="src/plugins/leaflet.markercluster.js"></script>
        <script src="src/jquery-ui.min.js"></script>

<!--    ***************  Begin Leaflet.Draw-->

        <script src="src/plugins/leaflet-draw/Leaflet.draw.js"></script>
        <script src="src/plugins/leaflet-draw/Leaflet.Draw.Event.js"></script>
        <link rel="stylesheet" href="src/plugins/leaflet-draw/leaflet.draw.css"/>

        <script src="src/plugins/leaflet-draw/Toolbar.js"></script>
        <script src="src/plugins/leaflet-draw/Tooltip.js"></script>

        <script src="src/plugins/leaflet-draw/ext/GeometryUtil.js"></script>
        <script src="src/plugins/leaflet-draw/ext/LatLngUtil.js"></script>
        <script src="src/plugins/leaflet-draw/ext/LineUtil.Intersect.js"></script>
        <script src="src/plugins/leaflet-draw/ext/Polygon.Intersect.js"></script>
        <script src="src/plugins/leaflet-draw/ext/Polyline.Intersect.js"></script>
        <script src="src/plugins/leaflet-draw/ext/TouchEvents.js"></script>

        <script src="src/plugins/leaflet-draw/draw/DrawToolbar.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Feature.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.SimpleShape.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Polyline.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Circle.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Marker.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Polygon.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Rectangle.js"></script>


        <script src="src/plugins/leaflet-draw/edit/EditToolbar.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/EditToolbar.Edit.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/EditToolbar.Delete.js"></script>

        <script src="src/plugins/leaflet-draw/Control.Draw.js"></script>

        <script src="src/plugins/leaflet-draw/edit/handler/Edit.Poly.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/Edit.SimpleShape.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/Edit.Circle.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/Edit.Rectangle.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/Edit.Marker.js"></script>

<!--    **************  End of Lealet Draw-->

        <style>
            #mapdiv {
                height:90vh;
            }

            .col-xs-12, .col-xs-6, .col-xs-4 {
                padding:3px;
            }

            #divProject {
                background-color: beige;
            }

            #divBUOWL {
                background-color: #ffffb3;
            }

            #divEagle {
                background-color: #ccffb3;
            }

            #divRaptor {
                background-color: #e6ffff;
            }

            .errorMsg {
                padding:0;
                text-align:center;
                background-color:darksalmon;
            }
            /* Style the header with a grey background and some padding */
.header {
  overflow: hidden;
  background-color: deepskyblue;
  padding: 10px 10px;
            }

/* Style the header links */
.header title {
  float: right;
  color: black;
  text-align: center;
  padding: 12px;
  text-decoration: none;
  font-size: 18px;
  line-height: 25px;
  border-radius: 4px;
}

/* Style the logo link (notice that we set the same value of line-height and font-size to prevent the header to increase when the font gets bigger */
.header a.logo {
  font-size: 25px;
  font-weight: bold;
}

/* Change the background color on mouse-over */
.header a:hover {
  background-color: #ddd;
  color: black;
}

/* Style the active/current link*/
.header a.active {
  background-color: dodgerblue;
  color: white;
}

/* Float the link section to the right */
.header-right {
  float: right;
}

/* Add media queries for responsiveness - when the screen is 500px wide or less, stack the links on top of each other */
@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  .header-right {
    float: none;
  }
}

        </style>
        <div class="header">
            <h1 class=" text-center ">Githioro</h1>
        </div>


    </head>
    <body>
        <div id="side-bar" class="col-md-3">
            <button id='btnLocate' class='btn btn-primary btn-block'>Locate</button><br>
            <!--<div id="divProject" class="col-xs-12">
                <div id="divProjectLabel" class="text-center col-xs-12">
                    <h4 id="lblProject">Linear Projects</h4>
                </div>
                <div id="divProjectError" class="errorMsg col-xs-12"></div>
                <div id="divFindProject" class="form-group has-error">
                    <div class="col-xs-6">
                        <input type="text" id="txtFindProject" class="form-control" placeholder="Project ID">
                    </div>
                    <div class="col-xs-6">
                        <button id="btnFindProject" class="btn btn-primary btn-block" disabled>Find Project</button>
                    </div>
                </div>
                <div class="" id="divProjectData"></div>
            </div>-->

            <div id="divPlot" class="col-xs-12">
                <div id="divPlotLabel" class="text-center col-xs-12">
                    <h4 id="lblPlot">Plot Search</h4>
                </div>
                <div id="divPlotError" class="errorMsg col-xs-12"></div>
                <div id="divFindPlot" class="form-group has-error">
                    <div class="col-xs-6">
                        <input type="text" id="txtFindPlot" class="form-control" placeholder="Plot ID">
                    </div>
                    <div class="col-xs-6">
                        <button id="btnFindPlot" class="btn btn-primary btn-block"  >Find Plot</button>
                    </div>
                </div>
                <div class="" id="divPlotData"></div>
            </div>

            <div id="divPlotFilter" class="col-xs-12">
            <div class="col-xs-2">
                <input type="radio" name="fltPlots" value="ALL" checked>ALL
            </div>

            <div class="col-xs-5">
                <input type="radio" name="fltPlots" value="Documented" >VALIDATON
            </div>

            <div class="col-xs-5">
                <input type="radio" name="fltPlots" value="N.documented " >NOT VALIDATED
            </div>

            </div>




            <!--<div id="divBUOWL" class="col-xs-12">
                <div id="divBUOWLLabel" class="text-center col-xs-12">
                    <h4 id="lblBUOWL">BUOWL Habitat</h4>
                </div>
                <div id="divBUOWLError" class="errorMsg col-xs-12"></div>
                <div id="divFindBUOWL" class="form-group has-error">
                    <div class="col-xs-6">
                        <input type="text" id="txtFindBUOWL" class="form-control" placeholder="Habitat ID">
                    </div>
                    <div class="col-xs-6">
                        <button id="btnFindBUOWL" class="btn btn-primary btn-block" disabled>Find BUOWL</button>
                    </div>
                </div>
                <div class="" id="divBUOWLData"></div>
            </div>-->

            <!--<div id="divEagle" class="col-xs-12">
                <div id="divEagleLabel" class="text-center col-xs-12">
                    <h4 id="lblEagle">Eagle Nests</h4>
                </div>
                <div id="divEagleError" class="errorMsg col-xs-12"></div>
                <div id="divFindEagle" class="form-group has-error">
                    <div class="col-xs-6">
                        <input type="text" id="txtFindEagle" class="form-control" placeholder="Eagle Nest ID">
                    </div>
                    <div class="col-xs-6">
                        <button id="btnFindEagle" class="btn btn-primary btn-block" disabled>Find Eagle Nest</button>
                    </div>
                </div>
                <div class="" id="divEagleData"></div>
            </div>-->

           <!--<div id="divRaptor" class="col-xs-12">
                <div id="divRaptorLabel" class="text-center col-xs-12">
                    <h4 id="lblRaptor">Raptor Nests</h4>
                </div>
                <div id="divRaptorError" class="errorMsg col-xs-12"></div>
                <div id="divFindRaptor" class="form-group has-error">
                    <div class="col-xs-6">
                        <input type="text" id="txtFindRaptor" class="form-control" placeholder="Raptor Nest ID">
                    </div>
                    <div class="col-xs-6">
                        <button id="btnFindRaptor" class="btn btn-primary btn-block" disabled>Find Raptor Nest</button>
                    </div>
                </div>
                <div class="" id="divRaptorData"></div>
            </div>-->

        </div>

        <div id="side-bar1" class="col-md-4">
                        <div id="divProject" class="col-xs-12">
                <div id="Label" class="text-center col-xs-12">
                    <h4 id="lblLegend">LEGEND</h4>
                </div>
                <div id="divFindProject" class="form-group has-error">
                    <table class="table">
                    <thead >
                        <tr >
                        <th scope="col">Color</th>
                        <th scope="col">Land Use</th>
                        <th scope="col">% Ha</th>
                        </tr>
                    </thead>

                    <tbody class="text-center">
                        <tr>
                          <th scope="row"><img src="img/residentialbrown.png" class="w-25 p-3"></th>
                          <td>Residential</td>
                          <td>40.9%</td>
                        </tr>
                    </tbody>

                    <tbody class="text-center">
                        <tr>
                          <th scope="row"><img src="img/educationalorange.png" class="w-25 p-3"></th>
                          <td>Educational</td>
                          <td>2.9%</td>
                        </tr>
                    </tbody>

                    <tbody class="text-center">
                        <tr>
                          <th scope="row"><img src="img/recreationalgreen.png"></th>
                          <td>Recreational</td>
                          <td>2.9%</td>
                        </tr>
                    </tbody>

                    <tbody class="text-center">
                        <tr>
                          <th scope="row"><img src="img/pubpurposeyellow.png"> <br></th>
                          <td>Public Purpose</td>
                          <td>NILL</td>
                        </tr>
                    </tbody>

                    <tbody class="text-center">
                        <tr>
                          <th scope="row"><img src="img/publicutilityblue.png"></th>
                          <td>Public Utility</td>
                          <td>NILL</td>
                        </tr>
                    </tbody>

                    <tbody class="text-center">
                        <tr>
                          <th scope="row"><img src="img/paleyellowagricultural.png"></th>
                          <td>Agricultural</td>
                          <td>NILL</td>
                        </tr>
                    </tbody>

                    </table>

                </div>
                <div class="" id="divProjectData"></div>
            </div>

        </div>


        <div id="mapdiv" class="col-md-12"></div>
        <script>
            var mymap;
            var lyrOSM;
            var lyrWatercolor;
            var lyrTopo;
            var lyrImagery;
            var lyrOutdoors;
            var lyrEagleNests;
            var lyrRaptorNests;
            var lyrClientLines;
            var lyrBUOWL;
            var lyrGBH;
            var lyrGith;
            var lyrBuildings;
            var lyrLandUse;
            var lyrSearch;
            var lyrMarkerCluster;
            var mrkCurrentLocation;
            var fgpDrawnItems;
            var ctlAttribute;
            var ctlScale;
            var ctlMouseposition;
            var ctlMeasure;
            var ctlEasybutton;
            var ctlSidebar;
            var ctlRsidebar
            var ctlLayers;
            var ctlDraw;
            var ctlStyle;
            var objBasemaps;
            var objOverlays;
            var arLayersIDs  = [];
            var arProjectIDs = [];
            var arHabitatIDs = [];
            var arEagleIDs   = [];
            var arRaptorIDs  = [];

            $(document).ready(function(){

                //  ********* Map Initialization ****************

                mymap = L.map('mapdiv', {center: [-0.979841,36.586415], zoom:16, attributionControl:false});

                ctlSidebar = L.control.sidebar('side-bar').addTo(mymap);

                ctlEasybutton = L.easyButton('glyphicon-transfer', function(){
                   ctlSidebar.toggle();
                }).addTo(mymap);

                ctlRsidebar = L.control.sidebar('side-bar1', {position: 'right'}).addTo(mymap);

                 ctlEasybutton = L.easyButton('glyphicon-cog', function(){
                   ctlRsidebar.toggle();
                }).addTo(mymap);

                ctlAttribute = L.control.attribution().addTo(mymap);
                ctlAttribute.addAttribution('OSM');
                ctlAttribute.addAttribution('&copy; <a href="http://nakuplan.com">Nakuplan Consultants Kenya</a>');

                ctlScale = L.control.scale({position:'bottomleft', metric:false, maxWidth:200}).addTo(mymap);

                ctlMouseposition = L.control.mousePosition().addTo(mymap);

                ctlStyle = L.control.styleEditor({position:'topright'}).addTo(mymap);
                ctlMeasure = L.control.polylineMeasure().addTo(mymap);

                //   *********** Layer Initialization **********

                lyrOSM = L.tileLayer.provider('OpenStreetMap.Mapnik');
                lyrTopo = L.tileLayer.provider('OpenTopoMap');
                lyrImagery = L.tileLayer.provider('Esri.WorldImagery');
                lyrOutdoors = L.tileLayer.provider('Thunderforest.Outdoors');
                mymap.addLayer(lyrOSM);

                fgpDrawnItems = new L.FeatureGroup();
                fgpDrawnItems.addTo(mymap);

                lyrBuildings = L.geoJSON.ajax('data/githioro/building.geojson').addTo(mymap);

                lyrLandUse = L.geoJSON.ajax('data/githioro/docs.geojson', {style: styleLanduseLandUse, onEachFeature: processLanduse, filter: fliterPlots}).addTo(mymap);
                lyrLandUse.on('data:loaded', function(){
                    arLayersIDs.sort(function(a,b){return a-b});
                    $("#txtFindPlot").autocomplete({
                        source:arLayersIDs
                    });
                });

                lyrGith = L.geoJSON.ajax('data/githioro/grace.geojson',{style: styleDocs, onEachFeature:processGith, filter: fliterPlots}).addTo(mymap);
                lyrGith.on('data:loaded', function(){
                    mymap.fitBounds(lyrGith.getBounds());






                // ********* Setup Layer Control  ***************

                objBasemaps = {
                    "Open Street Maps": lyrOSM,
                    "Topo Map":lyrTopo,
                    "Imagery":lyrImagery,
                };

                objOverlays = {
                    "Plots":lyrGith,
                    "Land Use":lyrLandUse,
                    "Buildings":lyrBuildings

                };

                ctlLayers = L.control.layers(objBasemaps, objOverlays).addTo(mymap);

                // **********  Setup Draw Control ****************

                ctlDraw = new L.Control.Draw({
                    draw:{
                        circle:false,
                        rectangle:false,
                    },
                    edit:{
                        featureGroup:fgpDrawnItems
                    }
                });
                ctlDraw.addTo(mymap);

                mymap.on('draw:created', function(e){
                    fgpDrawnItems.addLayer(e.layer);
                });

                // ************ Location Events **************

                mymap.on('locationfound', function(e) {
                    console.log(e);
                    if (mrkCurrentLocation) {
                        mrkCurrentLocation.remove();
                    }
                    mrkCurrentLocation = L.circle(e.latlng, {radius:e.accuracy/2}).addTo(mymap);
                    mymap.setView(e.latlng, 14);
                });

                mymap.on('locationerror', function(e) {
                    console.log(e);
                    alert("Location was not found");
                })

            });

            //  ********* BUOWL Functions

            function styleBUOWL(json){
                var att = json.properties;
                switch (att.hist_occup){
                    case 'Yes':
                        return {color:'deeppink', fillColor:'yellow'};
                        break;
                    case 'Undetermined':
                        return {color:'yellow'};
                        break;
                }
            }

            function processBUOWL(json, lyr){
                var att = json.properties;
                lyr.bindTooltip("<h4>Habitat ID: "+att.habitat_id+"</h4>Historically Occupied: "+att.hist_occup+"<br>Status: "+att.recentstatus);
                arHabitatIDs.push(att.habitat_id.toString())
            }

            function filterBUOWL(json){
                var att = json.properties;
                if (att.recentstatus=='REMOVED') {
                    return false;
                } else {
                    return true;
                }
            }

            $("#txtFindBUOWL").on('keyup paste', function(){
                var val = $("#txtFindBUOWL").val();
                testLayerAttribute(arHabitatIDs, val, "Habitat ID", "#divFindBUOWL", "#divBUOWLError", "#btnFindBUOWL");
            });

            $("#btnFindBUOWL").click(function(){
                var val = $("#txtFindBUOWL").val();
                var lyr = returnLayerByAttribute(lyrBUOWL,'habitat_id',val);
                if (lyr) {
                    if (lyrSearch) {
                        lyrSearch.remove();
                    }
                    lyrSearch = L.geoJSON(lyr.toGeoJSON(), {style:{color:'red', weight:1, opacity:0.5, fillOpacity:0.9}}).addTo(mymap);
                    mymap.fitBounds(lyr.getBounds().pad(1));
                    var att = lyr.feature.properties;
                    $("#divBUOWLData").html("<h4 class='text-center'>Attributes</h4><h5>Habitat: "+att.habitat+"</h5><h5>Historically Occupied: "+att.hist_occup+"</h5><h5>Recent Status: "+att.recentstatus+"</h5>");
                    $("#divBUOWLError").html("");
                } else {
                    $("#divBUOWLError").html("**** Habitat ID not found ****");
                }
            });

            $("#lblBUOWL").click(function(){
                $("#divBUOWLData").toggle();
            });

            // ************ Client Linears **********

            function styleClientLinears(json) {
                var att = json.properties;
                switch (att.type) {
                    case 'Pipeline':
                        return {color:'peru'};
                        break;
                    case 'Flowline':
                        return {color:'navy'};
                        break;
                    case 'Flowline, est.':
                        return {color:'navy', dashArray:"5,5"};
                        break;
                    case 'Electric Line':
                        return {color:'darkgreen'};
                        break;
                    case 'Access Road - Confirmed':
                        return {color:'darkred'};
                        break;
                    case 'Access Road - Estimated':
                        return {color:'darkred', dashArray:"5,5"};
                        break;
                    case 'Extraction':
                        return {color:'indigo'};
                        break;
                    default:
                        return {color:'darkgoldenrod'}
                }
            }

            function processClientLinears(json, lyr) {
                var att = json.properties;
                lyr.bindTooltip("<h4>Linear Project: "+att.Project+"</h4>Type: "+att.type+"<br>ROW Width: "+att.row_width);
                arProjectIDs.push(att.Project.toString());
            }

            $("#txtFindProject").on('keyup paste', function(){
                var val = $("#txtFindProject").val();
                testLayerAttribute(arProjectIDs, val, "PROJECT ID", "#divFindProject", "#divProjectError", "#btnFindProject");
            });

            $("#btnFindProject").click(function(){
                var val = $("#txtFindProject").val();
                var lyr = returnLayerByAttribute(lyrClientLines,'Project',val);
                if (lyr) {
                    if (lyrSearch) {
                        lyrSearch.remove();
                    }
                    lyrSearch = L.geoJSON(lyr.toGeoJSON(), {style:{color:'red', weight:10, opacity:0.5}}).addTo(mymap);
                    mymap.fitBounds(lyr.getBounds().pad(1));
                    var att = lyr.feature.properties;
                    $("#divProjectData").html("<h4 class='text-center'>Attributes</h4><h5>Type: "+att.type+"</h5><h5>ROW width: "+att.row_width+ "m </h5>");
                    $("#divProjectError").html("");
                } else {
                    $("#divProjectError").html("**** Project ID not found ****");
                }
            });

            $("#lblProject").click(function(){
                $("#divProjectData").toggle();
            });


            //********** STYLING GITHIORO POLYGONS **********//

            function styleDocs(json){
                var att = json.properties;
                switch(att.status){
                    case 'Documented':
                        return {color: 'orange', fillColor:'orange'};
                        break;

                    case 'N.documented':
                        return {color: 'black'};
                        break;

                }
            }

                function fliterPlots(json){
                    var att = json.properties;
                    var optFilter = $("input[name=fltPlots]:checked").val();
                    if(optFilter=='ALL'){
                        return true;
                    }else{
                        return (att.status==optFilter);
                    }
                }

                //**** search plot *****//
                function returnPlotByID(id){
                    var arLayers = lyrGith.getLayers();
                    for(i=0; i<arLayers.length-1;i++){
                        var featureID = arLayers[i].feature.properties.PLOT_NUMBE;
                        if(featureID == id){
                            return arLayers[i];
                            }
                        }
                    return false;
                }

                //*** find plot query ***//
                $("#btnFindPlot").click(function(){
                    var id = $("#txtFindPlot").val();
                    var lyr = returnPlotByID (id);
                    if (lyr){
                        if(lyrSearch){
                            lyrSearch.remove();
                        }
                        lyrSearch = L.geoJSON(lyr.toGeoJSON(),{style:{color:'red', weight:0.5, opacity:0.1}}).addTo(mymap);

                        mymap.fitBounds(lyr.getBounds().pad(0.5));
                        var att = lyr.feature.properties;
                        $("#divPlotData").html("<h4 class='text-center'>Plot Info</h4><h5>Land Use: "+att.LandUse+"<h5> <h5>Plot Sise: "+att.AREA1+" HA </h5> <h5>Documentation: "+att.status+"</h5> ");
                    }else{
                        $("#divPlotError").html("***Plot Not Inserted***");
                    }
                });


            function processGith (json, lyr){
            var att = json.properties;
                lyr.bindTooltip("<h4>Plot ID: "+att.PLOT_NUMBE+"</h4>Status:"+att.status+"<br> Land Use: "+att.LandUse+"<br> Plot Size in HA: "+att.AREA1 );
                arLayersIDs.push(att.PLOT_NUMBE.toString());
            }

                function testPlotTxtID(id){
                    if (arLayersIDs.indexOf(id)<0){
                    $("#divFindPlot").addClass("has-error");
                        $("#divPlotError").html("*** PLOT NOT FOUND");
                        $("#btnFindPlot").attr("disabled", true);
                        }else{
                        $("#divFindPlot").removeClass("has-error");
                        $("#divPlotError").html("");
                        $("#btnFindPlot").attr("disabled", false);
                    }

            }
                $("#txtFindPlot").on('keyup paste', function(){
                    var id = $("#txtFindPlot").val();
                    testPlotTxtID(id);
                });


                function styleLanduseLandUse(json){
                var att = json.properties;
                switch(att.LandUse){

                    case 'Public purpose':
                        return {color:'#ffffa6',fillColor:'#ffffa6'};
                        break;

                    case 'Proposed public purpose':
                        return {color:'#ffffa6',fillColor:'#ffffa6'};
                        break;

                    case 'Public utility':
                        return {color:'blue'};
                        break;


                    case 'industry':
                        return {color:'#e680ff'};
                        break;

                    case 'commercial':
                        return {color:'red'};
                        break;

                    case 'Transportation':
                        return {color:'grey'};
                        break;

                    case 'Educational':
                        return {color:'orange'};
                        break;

                    case 'High density Residential':
                        return {color:'brown'};
                        break;

                    case 'Medium Density Residential':
                        return {color:'brown'};
                        break;

                    case 'Proposed high density residential':
                        return {color:'#e6ccb3'};
                        break;

                    case 'Market':
                        return {color:'blue'};
                        break;

                    case 'Proposed recreation':
                        return {color:'green'};
                        break;

                    case 'Proposed commercial':
                        return {color:'red'};
                        break;

                }
            }

                function processLanduse (json, lyr){
                var att = json.properties;
                lyr.bindTooltip("<h4>Plot ID: "+att.PLOT_NUMBE+"</h4> Status:"+att.status+"<br> Land Use: "+att.LandUse);
                }

                $("input[name=fltPlots]").click(function(){
                    arLayersIDs = [];
                    lyrGith.refresh();
                });



            // *********  Eagle Functions *****************

            function returnEagleMarker(json, latlng){
                var att = json.properties;
                if (att.status=='ACTIVE NEST') {
                    var clrNest = 'deeppink';
                } else {
                    var clrNest = 'chartreuse';
                }
                arEagleIDs.push(att.nest_id.toString());
                return L.circle(latlng, {radius:804, color:clrNest,fillColor:'chartreuse', fillOpacity:0.5}).bindTooltip("<h4>Eagle Nest: "+att.nest_id+"</h4>Status: "+att.status);
            }

            $("#txtFindEagle").on('keyup paste', function(){
                var val = $("#txtFindEagle").val();
                testLayerAttribute(arEagleIDs, val, "Eagle Nest ID", "#divFindEagle", "#divEagleError", "#btnFindEagle");
            });

            $("#btnFindEagle").click(function(){
                var val = $("#txtFindEagle").val();
                var lyr = returnLayerByAttribute(lyrEagleNests,'nest_id',val);
                if (lyr) {
                    if (lyrSearch) {
                        lyrSearch.remove();
                    }
                    lyrSearch = L.circle(lyr.getLatLng(), {radius:800, color:'red', weight:10, opacity:0.5, fillOpacity:0}).addTo(mymap);
                    mymap.setView(lyr.getLatLng(), 14);
                    var att = lyr.feature.properties;
                    $("#divEagleData").html("<h4 class='text-center'>Attributes</h4><h5>Status: "+att.status+"</h5>");
                    $("#divEagleError").html("");
                } else {
                    $("#divEagleError").html("**** Eagle Nest ID not found ****");
                }
            });

            $("#lblEagle").click(function(){
                $("#divEagleData").toggle();
            });

            //  *********** Raptor Functions

            function returnRaptorMarker(json, latlng){
                var att = json.properties;
                arRaptorIDs.push(att.Nest_ID.toString());
                switch (att.recentspecies) {
                    case 'Red-tail Hawk':
                        var radRaptor = 533;
                        break;
                    case 'Swainsons Hawk':
                        var radRaptor = 400;
                        break;
                    default:
                        var radRaptor = 804;
                        break;
                }
                switch (att.recentstatus) {
                    case 'ACTIVE NEST':
                        var optRaptor = {radius:radRaptor, color:'deeppink', fillColor:"cyan", fillOpacity:0.5};
                        break;
                    case 'INACTIVE NEST':
                        var optRaptor = {radius:radRaptor, color:'cyan', fillColor:'cyan', fillOpacity:0.5};
                        break;
                    case 'FLEDGED NEST':
                        var optRaptor = {radius:radRaptor, color:'deeppink', fillColor:"cyan", fillOpacity:0.5, dashArray:"2,8"};
                        break;
                }
                return L.circle(latlng, optRaptor).bindPopup("<h4>Raptor Nest: "+att.Nest_ID+"</h4>Status: "+att.recentstatus+"<br>Species: "+att.recentspecies+"<br>Last Survey: "+att.lastsurvey);
            }

            $("#txtFindRaptor").on('keyup paste', function(){
                var val = $("#txtFindRaptor").val();
                testLayerAttribute(arRaptorIDs, val, "Raptor Nest ID", "#divFindRaptor", "#divRaptorError", "#btnFindRaptor");
            });

            $("#btnFindRaptor").click(function(){
                var val = $("#txtFindRaptor").val();
                var lyr = returnLayerByAttribute(lyrRaptorNests,'Nest_ID',val);
                if (lyr) {
                    if (lyrSearch) {
                        lyrSearch.remove();
                    }
                    var att = lyr.feature.properties;
                    switch (att.recentspecies) {
                        case 'Red-tail Hawk':
                            var radRaptor = 533;
                            break;
                        case 'Swainsons Hawk':
                            var radRaptor = 400;
                            break;
                        default:
                            var radRaptor = 804;
                            break;
                    }
                    lyrSearch = L.circle(lyr.getLatLng(), {radius:radRaptor, color:'red', weight:10, opacity:0.5, fillOpacity:0}).addTo(mymap);
                    mymap.setView(lyr.getLatLng(), 14);
                    $("#divRaptorData").html("<h4 class='text-center'>Attributes</h4><h5>Status: "+att.recentstatus+"</h5><h5>Species: "+att.recentspecies+"</h5><h5>Last Survey: "+att.lastsurvey+"</h5>");
                    $("#divRaptorError").html("");
                } else {
                    $("#divRaptorError").html("**** Raptor Nest ID not found ****");
                }
            });

            $("#lblRaptor").click(function(){
                $("#divRaptorData").toggle();
            });

            //  *********  jQuery Event Handlers  ************

            $("#btnLocate").click(function(){
                mymap.locate();
            });

            //  ***********  General Functions *********

            function LatLngToArrayString(ll) {
                return "["+ll.lat.toFixed(5)+", "+ll.lng.toFixed(5)+"]";
            }

            function returnLayerByAttribute(lyr,att,val) {
                var arLayers = lyr.getLayers();
                for (i=0;i<arLayers.length-1;i++) {
                    var ftrVal = arLayers[i].feature.properties[att];
                    if (ftrVal==val) {
                        return arLayers[i];
                    }
                }
                return false;
            }

            function testLayerAttribute(ar, val, att, fg, err, btn) {
                if (ar.indexOf(val)<0) {
                    $(fg).addClass("has-error");
                    $(err).html("**** "+att+" NOT FOUND ****");
                    $(btn).attr("disabled", true);
                } else {
                    $(fg).removeClass("has-error");
                    $(err).html("");
                    $(btn).attr("disabled", false);
                }
            }

            });

        </script>
    </body>
</html>
