<?php include("../includes/init.php");?>
<?php
    if (logged_in()) {
        $username=$_SESSION['username'];
        if (!verify_user_group($pdo, $username, "Planners")) {
            set_msg("User '{$username}' does not have permission to view this page");
            redirect('../index.php');
        }
    } else {
        set_msg("Please log-in and try again");
        redirect('../index.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Nuthu Market Center</title>
        <link rel="stylesheet" href="src/leaflet.css">
        <link rel="stylesheet" href="src/css/bootstrap.css">
        <link rel="stylesheet" href="src/plugins/L.Control.MousePosition.css">
        <link rel="stylesheet" href="src/plugins/L.Control.Sidebar.css">
        <link rel="stylesheet" href="src/plugins/Leaflet.PolylineMeasure.css">
        <link rel="stylesheet" href="src/plugins/easy-button.css">
        <link rel="stylesheet" href="src/plugins/leaflet-styleeditor/css/Leaflet.StyleEditor.css">
        <link rel="stylesheet" href="src/css/font-awesome.min.css">
        <link rel="stylesheet" href="src/plugins/leaflet.awesome-markers.css">
        <link rel="stylesheet" href="src/plugins/leaflet-mapkey/MapkeyIcons.css">
        <link rel="stylesheet" href="src/plugins/leaflet-mapkey/L.Icon.Mapkey.css">
        <link rel="stylesheet" href="src/plugins/MarkerCluster.css">
        <link rel="stylesheet" href="src/plugins/MarkerCluster.Default.css">

        <script src="src/leaflet-src.js"></script>
        <script src="src/jquery-3.2.0.min.js"></script>
        <script src="src/plugins/L.Control.MousePosition.js"></script>
        <script src="src/plugins/L.Control.Sidebar.js"></script>
        <script src="src/plugins/Leaflet.PolylineMeasure.js"></script>
        <script src="src/plugins/easy-button.js"></script>
        <script src="src/plugins/leaflet-providers.js"></script>
        <script src="src/plugins/leaflet-styleeditor/javascript/Leaflet.StyleEditor.js"></script>
        <script src="src/plugins/leaflet-styleeditor/javascript/Leaflet.StyleForms.js"></script>
        <script src="src/plugins/leaflet.ajax.min.js"></script>
        <script src="src/plugins/leaflet.sprite.js"></script>
        <script src="src/plugins/leaflet.awesome-markers.min.js"></script>
        <script src="src/plugins/leaflet-mapkey/L.Icon.Mapkey.js"></script>
        <script src="src/plugins/leaflet.markercluster.js"></script>

<!--    ***************  Begin Leaflet.Draw-->

        <script src="src/plugins/leaflet-draw/Leaflet.draw.js"></script>
        <script src="src/plugins/leaflet-draw/Leaflet.Draw.Event.js"></script>
        <link rel="stylesheet" href="src/plugins/leaflet-draw/leaflet.draw.css"/>

        <script src="src/plugins/leaflet-draw/Toolbar.js"></script>
        <script src="src/plugins/leaflet-draw/Tooltip.js"></script>

        <script src="src/plugins/leaflet-draw/ext/GeometryUtil.js"></script>
        <script src="src/plugins/leaflet-draw/ext/LatLngUtil.js"></script>
        <script src="src/plugins/leaflet-draw/ext/LineUtil.Intersect.js"></script>
        <script src="src/plugins/leaflet-draw/ext/Polygon.Intersect.js"></script>
        <script src="src/plugins/leaflet-draw/ext/Polyline.Intersect.js"></script>
        <script src="src/plugins/leaflet-draw/ext/TouchEvents.js"></script>

        <script src="src/plugins/leaflet-draw/draw/DrawToolbar.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Feature.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.SimpleShape.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Polyline.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Circle.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Marker.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Polygon.js"></script>
        <script src="src/plugins/leaflet-draw/draw/handler/Draw.Rectangle.js"></script>


        <script src="src/plugins/leaflet-draw/edit/EditToolbar.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/EditToolbar.Edit.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/EditToolbar.Delete.js"></script>

        <script src="src/plugins/leaflet-draw/Control.Draw.js"></script>

        <script src="src/plugins/leaflet-draw/edit/handler/Edit.Poly.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/Edit.SimpleShape.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/Edit.Circle.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/Edit.Rectangle.js"></script>
        <script src="src/plugins/leaflet-draw/edit/handler/Edit.Marker.js"></script>

<!--    **************  End of Lealet Draw-->

        <style>
            #mapdiv {
                height:90vh;
            }

            .col-xs-12, .col-xs-6, col-xs-4{
                padding: 3px;
            }

            #divProject{

                background-color: white;
                padding-bottom: 20px;
                border-radius: 10px;
            }
            #side-bar{
                background-color: lightblue;

            }
            .errorMsg{
                padding:20px;
                text-align: center;
                background-color: darksalmon;
            }
            .header{
                background-color: beige;
                text-align: center;

            }

        </style>
        <div class="header">
            <h1 class=" text-center " style="margin-bottom: 40px;">Nuthu</h1>
        </div>

    </head>
    <body>

        <div id="side-bar" class="col-md-3">
            <button id='btnLocate' class='btn btn-primary btn-block'>Locate</button><br>

             <div id="divProject" class="col-xs-12">
                <div id="divProjectLabel" class="text-center col-xs-12">
                    <h4>Plot Search</h4>
                </div>

                <div id="divProjectError" class="errorMsg col-xs-12">

                </div>
                <div id="divFindProject" class="form-group">
                    <div class="col-xs-6">
                        <input type="text" id="txtFindPlot" class="form-control" placeholder="Project ID">
                    </div>
                </div>
                <div class="col-xs-6">
                        <button id="btnFindPlot" class="btn btn-primary btn-block">Find Project</button>
                    </div>
                <div class="" id="divProjectData">

                </div>
            </div>
        </div>


        <div id="mapdiv" class="col-md-12"></div>
        <script>
            var mymap;
            var lyrOSM;
            var lyrWatercolor;
            var lyrTopo;
            var lyrImagery;
            var lyrOutdoors;
            var lyrEagleNests;
            var lyrRaptorNests;
            var lyrClientLines;
            var lyrMarkerCluster;
            var lyrBOUML;
            var lyrSearch;
            var lyrPlots;
            var lyrPoints;
            var lyrRoads;
            var lyrBuildings;
            var lyrBoundary;
            var lyrSearch;
            var mrkCurrentLocation;
            var fgpDrawnItems;
            var ctlAttribute;
            var ctlScale;
            var ctlMouseposition;
            var ctlMeasure;
            var ctlEasybutton;
            var ctlSidebar;
            var ctlLayers;
            var ctlDraw;
            var ctlStyle;
            var objBasemaps;
            var objOverlays;

            $(document).ready(function(){
                //*************** map initilisation section **************//

                //****** replace with default area coordinates ********//
                mymap = L.map('mapdiv', {center:[-0.442, 36.33], zoom:17, attributionControl:true});

                ctlStyle = L.control.styleEditor({position:'topright'}).addTo(mymap);

                ctlSidebar = L.control.sidebar('side-bar').addTo(mymap);

                ctlEasybutton = L.easyButton('glyphicon-transfer', function(){
                   ctlSidebar.toggle();
                }).addTo(mymap);

                ctlAttribute = L.control.attribution().addTo(mymap);
                ctlAttribute.addAttribution('OSM');
                ctlAttribute.addAttribution('Edith Rosasi');
                ctlAttribute.addAttribution('&copy; <a href="http://nakuplan.com.com">Nakuplan Consultants</a>');

                ctlScale = L.control.scale({position:'bottomleft', metric:false, maxWidth:200}).addTo(mymap);

                ctlMouseposition = L.control.mousePosition().addTo(mymap);

                ctlMeasure = L.control.polylineMeasure().addTo(mymap);


                //****** layer initialisation ********//

                lyrOSM = L.tileLayer.provider('OpenStreetMap.Mapnik');
                lyrTopo = L.tileLayer.provider('OpenTopoMap');
                lyrImagery = L.tileLayer.provider('Esri.WorldImagery');
                lyrOutdoors = L.tileLayer.provider('Thunderforest.Outdoors');
                lyrWatercolor = L.tileLayer.provider('Stamen.Watercolor');
                mymap.addLayer(lyrOSM);


                fgpDrawnItems = new L.FeatureGroup();
                fgpDrawnItems.addTo(mymap);

                lyrEagleNests = L.geoJSON.ajax('data/wildlife_eagle.geojson', {pointToLayer:returnEagleMarker}).addTo(mymap);


                lyrMarkerCluster = L.markerClusterGroup();
                lyrRaptorNests = L.geoJSON.ajax('data/wildlife_raptor.geojson', {pointToLayer:returnRaptorMarker});
                lyrRaptorNests.on('data:loaded', function(){
                    lyrMarkerCluster.addLayer(lyrRaptorNests);
                    lyrMarkerCluster.addTo(mymap);
                });

                lyrPlots = L.geoJSON.ajax('data/nuthu/nuthu_owners.geojson',{style:stylePlots, onEachFeature:processPlots}).addTo(mymap);

                lyrBuildings = L.geoJSON.ajax('data/nuthu/nuthu_buildings.geojson',{style:stylePlots, onEachFeature:processPlots}).addTo(mymap);

                var lyrPoints;


                var lyrBoundary;

                //*********** Setup layer Control **************//
                objBasemaps = {
                    "Open Street Maps": lyrOSM,
                    "Topo Map":lyrTopo,
                    "Imagery":lyrImagery,
                    "Outdoors":lyrOutdoors,
                    "Watercolor":lyrWatercolor
                };

                objOverlays = {
                    "Plots":lyrPlots,
                    "Buildings":lyrBuildings,
                    "Drawn Items":fgpDrawnItems
                };

                ctlLayers = L.control.layers(objBasemaps, objOverlays).addTo(mymap);

               //************** Setup Draw Control **************//

                ctlDraw = new L.Control.Draw({
                    draw:{
                        circle:false,
                        rectangle:false,
                    },
                    edit:{
                        featureGroup:fgpDrawnItems
                    }
                });
                ctlDraw.addTo(mymap);

                mymap.on('draw:created', function(e){
                    fgpDrawnItems.addLayer(e.layer);



            //******* Location Events ************//

                mymap.on('locationfound', function(e) {
                    console.log(e);
                    if (mrkCurrentLocation) {
                        mrkCurrentLocation.remove();
                    }
                    mrkCurrentLocation = L.circle(e.latlng, {radius:e.accuracy/2}).addTo(mymap);
                    mymap.setView(e.latlng, 14);
                });

                mymap.on('locationerror', function(e) {
                    console.log(e);
                    alert("Location was not found");
                })

            });

            //******* Nuthu Functions *******//
            function stylePlots(json){
                var att = json.properties;
                switch (att.LandUse){
                    case 'Public purpose':
                        return {color:'yellow'};
                        break;
                    case 'Commercial':
                        return {color:'red'};
                        break;
                    case 'Residential':
                        return {color:'peru'};
                        break;
                    case 'High density residential':
                        return {color:'green'};
                        break;
                    case 'Medium Density Residential':
                        return {color:'brown'};
                        break;
                    case 'Transportation':
                        return {color:'grey'};
                        break;
                    case 'Transportation':
                        return {color:'yellow'};
                        break;
                    case 'Industrial':
                        return {color:'purple'};
                        break;
                    case 'Mixed use':
                        return {color:'peru'};
                        break;
                    case 'Market':
                        return {color:'yellow'};
                        break;
                    case 'Recreational':
                        return {color:'green'};
                        break;
                    case 'Urban agriculture':
                        return {color:'green'};
                        break;

                }
            }

                function processPlots(json, lyr){
                var att = json.properties;
                lyr.bindTooltip("<h4>Plot ID: "+att.PlotNum+"</h4><br>Land Use: "+att.LandUse+"<br>Area: "+att.Area+" HA<br> Owner:"+att.F4 );
            }

            //*******  NUTHU SEARCH FUNCTION *******//
            function returnPlotByID(id){
                var arLayers = lyrPlots.getLayers();
                for(i=0;i<arLayers.length-1;i++){
                    var featureID = arLayers[i].feature.properties.PlotNum;
                    console.log(featureID);
                    if(featureID==id ){
                        return arLayers[i];
                    }
                }
                return flase;
            }
            $("#btnFindPlot").click(function(){
                var id = $("#txtFindPlot").val();
                var lyr = returnPlotByID(id);
                if(lyr){
                    if(lyrSearch){
                        lyrSearch.remove();
                    }
                    lyrSearch = L.geoJSON(lyr.toGeoJSON(),{style:{color:'black',weigth:20,
                    opacity:0.5}}).addTo(mymap);
                    mymap.fitBounds(lyr.getBounds().pad(1));
                    var att = lyr.feature.properties;
                    $("#divProjectData").html("<h4 class='text-center'>Search Results</h4><h5>Plot Number: "+att.PlotNum+"</h5> <h5>Land Use: "+att.LandUse+ " </h5><h5>Owner: "+att.F4+ " </h5>");
                }else{
                    $("#divProjectError").html("*****Plot Search Found*****");
                }
            });



            //*******  CLIENT LINEARS *******//

            function styleClientLinears(json){
                var att = json.properties;
                switch (att.type){
                    case 'Pipeline':
                        return {color:'peru'};
                        break;
                    case 'Flowline':
                        return {color:'navy'};
                        break;
                    case 'Flowline, est.':
                        return {color:'navy', dashArray:"5,5"};
                        break;
                    case 'Electric Line':
                        return {color:'darkgreen'};
                        break;
                    case 'Access Road - Confirmed':
                        return {color:'darkred'};
                        break;
                    case 'Access Road - Estimated':
                        return {color:'darkred', dashArray:"5,5"};
                        break;
                    case 'Extraction':
                        return {color:'indigo'};
                        break;
                    default:
                        return {color:'darkgoldenrod'};
                        break;
                }
            }
            function processClientLinears(json, lyr){
                var att = json.properties;
                lyr.bindTooltip("<h4>Linear Project: "+att.Project+"</h4>Type: "+att.type+"<br>Row Width: "+att.row_width);
            }

            function returnClientLineByID(id){
                var arLayers = lyrClientLines.getLayers();
                for(i=0;i<arLayers.length-1;i++){
                    var featureID = arLayers[i].feature.properties.Project;
                    console.log(featureID);
                    if(featureID==id ){
                        return arLayers[i];
                    }
                }
                return flase;
            }

            $("#btnFindProject").click(function(){
                var id = $("#txtFindProject").val();
                var lyr = returnClientLineByID(id);
                if(lyr){
                    if(lyrSearch){
                        lyrSearch.remove();
                    }
                    lyrSearch = L.geoJSON(lyr.toGeoJSON(),{style:{color:'red',weigth:10,
                    opacity:0.5}}).addTo(mymap);
                    mymap.fitBounds(lyr.getBounds().pad(1));
                    var att = lyr.feature.properties;
                    $("#divProjectData").html("<h4 class='text-center'>Attributes</h4><h5>Type: "+att.type+"</h5><h5>Row Width: "+att.row_width+ " m </h5>");
                }else{
                    $("#divProjectError").html("*****Project ID Not Found*****");
                }
            });

            // ********** Eagle Functions **************//

             function returnEagleMarker(json, latlng){
                var att = json.properties;
                if (att.status=='ACTIVE NEST') {
                    var clrNest = 'deeppink';
                } else {
                    var clrNest = 'green';
                }
                return L.circle(latlng, {radius:804, color:clrNest,fillColor:'green', fillOpacity:0.5}).bindTooltip("<h4>Eagle Nest: "+att.nest_id+"</h4>Status: "+att.status);
            }

            // ********** Raptor Functions **************//

            function returnRaptorMarker(json, latlng){
                var att = json.properties;
                switch (att.recentspecies) {
                    case 'Red-tail Hawk':
                        var radRaptor = 533;
                        break;
                    case 'Swainsons Hawk':
                        var radRaptor = 400;
                        break;
                    default:
                        var radRaptor = 804;
                        break;
                }
                switch (att.recentstatus) {
                    case 'ACTIVE NEST':
                        var optRaptor = {radius:radRaptor, color:'deeppink', fillColor:"blue", fillOpacity:0.5};
                        break;
                    case 'INACTIVE NEST':
                        var optRaptor = {radius:radRaptor, color:'blue', fillColor:'blue', fillOpacity:0.5};
                        break;
                    case 'FLEDGED NEST':
                        var optRaptor = {radius:radRaptor, color:'deeppink', fillColor:"blue", fillOpacity:0.5, dashArray:"2,8"};
                        break;
                }
                return L.circle(latlng, optRaptor).bindPopup("<h4>Raptor Nest: "+att.Nest_ID+"</h4>Status: "+att.recentstatus+"<br>Species: "+att.recentspecies+"<br>Last Survey: "+att.lastsurvey);

            }




            //******* JQUERY event handlers *******//

             $("#btnLocate").click(function(){
                    mymap.locate();
                });


            // ************** General functions ***************//

            function LatLngToArrayString(ll) {
                return "["+ll.lat.toFixed(5)+", "+ll.lng.toFixed(5)+"]";
            }
         });

        </script>

<!--
        <div class="header">
            <h1>Nuthu Market Center</h1>
        </div>

        <div class="p-body">
            <p>Urban Planner: Ivy Gichuki</p>
        </div><div class="p-body">
            <p>Urban Mapper: Rosasi Edith</p>
        </div><div class="p-body">
            <p>Facts about Nuthu Center</p>
        </div><div class="p-body">
            <p>Facts about Nuthu Center</p>
        </div><div class="p-body">
            <p>Facts about Nuthu Center</p>
        </div>
-->

    </body>
</html>
